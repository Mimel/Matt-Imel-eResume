package display;

public interface FooterComponent {
	void drawMessages(String[] msgs);
}
