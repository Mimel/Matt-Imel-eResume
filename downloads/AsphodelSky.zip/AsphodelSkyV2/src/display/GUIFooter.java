package display;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

/**
 * The bottom-most portion of the Asphodel Sky GUI, this typically contains descriptions or some sort
 * of text feed, depending on the mode of the component.
 * @author Matt Imel
 *
 */
public class GUIFooter extends GUIComponent implements FooterComponent {
	
	/**
	 * The list of messages to write to the component.
	 */
	private String[] messages;

	public GUIFooter(int x, int y, int w, int h) {
		super(x, y, w, h);
		
		this.messages = new String[1];
		
		//2 possible displays.
		this.modes = new String[2];
		//The messages currently listed.
		this.modes[0] = "DISPLAY_MESSAGES";
		//The description of a selected entity.
		this.modes[1] = "DISPLAY_DESCRIPT";
	}
	
	@Override
	public void drawMessages(String[] msgs) {
		this.messages = msgs;
		this.repaint();
	}
	
	/**
	 * Draws the footer.
	 */
	@Override
	protected void paintComponent(Graphics g) {
		//Background
		g.setColor(new Color(255, 175, 175));
		g.fillRect(0, 0, width, height);
		
		//Font
		g.setColor(new Color(0, 0, 0));
		
		//Messages
		g.setFont(new Font("Verdana", Font.PLAIN, 14));
		for(int x = 0; x < messages.length; x++) {
			if(messages[x] != null) {
				g.drawString(messages[x], 50, (15 * x) + 20);
			}
		}
	}
	
}
