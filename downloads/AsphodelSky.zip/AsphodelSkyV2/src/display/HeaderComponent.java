package display;

public interface HeaderComponent {
	//TODO
}