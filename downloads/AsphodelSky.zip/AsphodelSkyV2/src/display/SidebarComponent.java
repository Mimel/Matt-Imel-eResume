package display;

import entity.Combatant;

public interface SidebarComponent {
	void drawCombatantInfo(Combatant c);
}
