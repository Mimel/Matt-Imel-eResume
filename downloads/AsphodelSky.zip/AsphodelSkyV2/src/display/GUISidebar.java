package display;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import entity.Combatant;

/**
 * A component of the Asphodel Sky GUI containing player information.
 * @author Matt Imel
 */
public class GUISidebar extends GUIComponent implements SidebarComponent {
	
	/**
	 * The combatant that is being focused on. If the component is
	 * in mode "CombatantDisplay", this combatant's stats is shown
	 * on the sidebar.
	 * 
	 * TODO: reciprocation is dangerous, switch out of Combatant.
	 */
	Combatant combatantFocus;

	public GUISidebar(int x, int y, int w, int h) {
		super(x, y, w, h);
		
		modes = new String[]{"CombatantDisplay", "Mode3", "Mode4"};
		selectedMode = modes[0];
	}
	
	@Override
	public void drawCombatantInfo(Combatant c) {
		this.combatantFocus = c;
		this.repaint();
	}
	
	/**
	 * Draws the sidebar graphics.
	 */
	@Override
	protected void paintComponent(Graphics g) { 
		g.setColor(new Color(0, 200, 0));
		g.fillRect(0, 0, width, height);
		
		g.setColor(new Color(0, 0, 0));
		g.setFont(new Font("Verdana", Font.PLAIN, 24));
		if(combatantFocus != null) {
			g.drawString(combatantFocus.getName(), xPos + 35, yPos + 25);
			g.drawString(combatantFocus.getTitle(), xPos + 35, yPos + 50);
			g.drawString("Health: " + combatantFocus.getHealth() + "/" + combatantFocus.getMaxHealth(), xPos + 35, yPos + 75);
		}
	}
}
