package display;

import grid.Tile;

public interface FocusComponent {
	void drawGrid(Tile[][] grid);
}
