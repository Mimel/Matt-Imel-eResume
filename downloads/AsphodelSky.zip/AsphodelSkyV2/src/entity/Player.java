package entity;

import item.Catalog;

/**
 * The player (You). 
 * @author Matt Imel
 */
public class Player implements Combatant {
	
	/**
	 * The id of the player. This value should ALWAYS be zero.
	 * TODO: This assumes that there can be only one player.
	 */
	private final int id;
	
	/**
	 * The title of the player, denoting a brief description of the player's abilities.
	 */
	private String title;
	
	/**
	 * The name of the player.
	 */
	private String name;
	
	/**
	 * The X-coordinate of the player on the grid.
	 */
	private int xPosition;
	
	/**
	 * The Y-coordinate of the player on the grid.
	 */
	private int yPosition;
	
	/**
	 * The current amount of health the player has.
	 */
	private int currentHealth;
	
	/**
	 * The maximum amount of health the player has.
	 */
	private int maxHealth;
	
	/**
	 * The inventory of the player.
	 */
	private Catalog inventory;
	
	public Player(String name, String title, int x, int y, int health) {
		this.id = 0;
		this.name = name;
		this.title = title;
		
		this.xPosition = x;
		this.yPosition = y;
		
		this.maxHealth = health;
		this.currentHealth = health;
		
		this.inventory = new Catalog();
	}
	
	public int getId() { return id; }
	
	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String n) {
		name = n;
	}
	
	public int getX() { return xPosition; }
	public int getY() { return yPosition; }
	
	public void setX(int newX) { xPosition = newX; }
	public void setY(int newY) { yPosition = newY; }
	
	public Catalog getInventory() { return inventory; }

	@Override
	public int getHealth() {
		return currentHealth;
	}
	
	@Override
	public int getMaxHealth() {
		return maxHealth;
	}

	@Override
	public void decreaseHealthBy(int healthLoss) {
		if(healthLoss > currentHealth) {
			currentHealth = 0;
		} else {
			currentHealth -= healthLoss;
		}
	}

	@Override
	public void increaseHealthBy(int healthGain) {
		if(currentHealth + healthGain > maxHealth) {
			currentHealth = maxHealth;
		} else {
			currentHealth += healthGain;
		}
	}
}
