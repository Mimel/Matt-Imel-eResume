package entity;

import item.Catalog;

/**
 * A combatant is an occupant that is able to fight; this implies that they have all the attributes that a typical player has,
 * such as health, momentum, an inventory, and equipment.
 * @author Matt Imel
 */
public interface Combatant extends Occupant {
	
	/**
	 * Retrieves the current health of the combatant. Implementors must declare a global health variable,
	 * with a value less than or equal to the combatant's maximum health.
	 * @return The current health of the combatant.
	 * @see getMaxHealth
	 */
	public int getHealth();
	
	/**
	 * Retrieves the maximum health of the combatant. Implementors must declare a global max health variable.
	 * @return The maximum health of the combatant.
	 */
	public int getMaxHealth();
	
	/**
	 * Decreases the amount of current health by a given amount. Implementors must declare a global health variable.
	 * @param subtrahend The amount of health to subtract.
	 */
	public void decreaseHealthBy(int subtrahend);
	
	/**
	 * Increases the amount of current health by a given amount. Implementors must declare both a global health and max health variable.
	 * @param addend The amount of health to add.
	 */
	public void increaseHealthBy(int addend);
	
	/**
	 * Retrieves the inventory of the combatant. Implementors must declare a Catalog variable.
	 * @return The inventory of the combatant.
	 */
	public Catalog getInventory();
}
